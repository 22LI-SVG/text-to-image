// Your Hugging Face API key
const HUGGINGFACE_API_KEY = "your-huggingface-api-key";
  
// Elements
const generateButton = document.getElementById("generate");
const promptInput = document.getElementById("prompt");
const resultImage = document.getElementById("resultImage");

// Generate Image Function
async function generateImage(prompt) {
  const apiUrl = "https://api-inference.huggingface.co/models/CompVis/stable-diffusion-v1-4";

  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${HUGGINGFACE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ inputs: prompt }),
    });

    if (!response.ok) {
      throw new Error("Error generating image. Please try again.");
    }

    // Convert response to image blob
    const blob = await response.blob();
    const imageUrl = URL.createObjectURL(blob);

    // Display the image
    resultImage.src = URL;
    resultImage.style.display = "block";
  } catch (error) {
    alert(error.message);
  }
}

// Event Listener
generateButton.addEventListener("click", () => {
  const prompt = promptInput.value.trim();
  if (prompt) {
    resultImage.style.display = "none"; // Hide old image while generating
    generateImage(prompt);
  } else {
    alert("a lonely tree in autumn.");
  }
});